#include "../include/utils.hpp"
#include <iostream>

int contador = 0;
void contadorLlamadas(){
  contador++;
}

void contador_unos(){
    contadorLlamadas(); 

    int leer;         
    int contador = 0; 

    std::cout<< "Ingrese los numeros de la secuencia binaria, para terminar introduzca un numero distinto de 0 y 1:\n";

    do {
        std::cout << "=> ";
        std::cin >> leer;

        if (leer == 1) {
            contador++;
        }

    } while (leer == 0 || leer == 1);

    std::cout << "\nCantidad de unos ingresados: " << contador<<"\n";
    std::cout << "Total de llamada a funciones: " << ::contador << "\n";
}

void elevar(int base, int exponente){
      contadorLlamadas(); 
    
    int contador = 1;

    for (int i = 0; i < exponente; i++) {
        contador *= base;
    }

    std::cout << "\nLa potencia de " << base << " elevado a " << exponente << " es: " << contador << "\n";
    std::cout << "Total de llamadas a funciones hasta ahora: " << ::contador << "\n\n";
}
